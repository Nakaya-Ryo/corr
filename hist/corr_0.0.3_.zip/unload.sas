filename P6911276 list;
%put NOTE: Unloading package corr, version 0.0.3, license MIT;
%put NOTE- *** START ***;
proc sql;
  create table WORK._%sysfunc(datetime(), hex16.)_ as
  select memname, objname, objtype
  from dictionary.catalogs
  where 
  (
   objname in ("*"
   ,'CORRMETA'
   ,'CORRIML'
   ,'CORRCASLUDF'
   %put NOTE- Element of type macro generated from the file "association_matrix.sas" will be deleted;
   %put NOTE- ;
   ,"ASSOCIATION_MATRIX                                              "
   %put NOTE- Element of type macro generated from the file "gtl_bar.sas" will be deleted;
   %put NOTE- ;
   ,"GTL_BAR                                                         "
   %put NOTE- Element of type macro generated from the file "gtl_box.sas" will be deleted;
   %put NOTE- ;
   ,"GTL_BOX                                                         "
   %put NOTE- Element of type macro generated from the file "gtl_crosstable.sas" will be deleted;
   %put NOTE- ;
   ,"GTL_CROSSTABLE                                                  "
   %put NOTE- Element of type macro generated from the file "gtl_ellipse.sas" will be deleted;
   %put NOTE- ;
   ,"GTL_ELLIPSE                                                     "
   %put NOTE- Element of type macro generated from the file "gtl_kernel.sas" will be deleted;
   %put NOTE- ;
   ,"GTL_KERNEL                                                      "
   %put NOTE- Element of type macro generated from the file "gtl_mosaic.sas" will be deleted;
   %put NOTE- ;
   ,"GTL_MOSAIC                                                      "
   %put NOTE- Element of type macro generated from the file "gtl_reg.sas" will be deleted;
   %put NOTE- ;
   ,"GTL_REG                                                         "
   %put NOTE- Element of type macro generated from the file "gtl_scatter.sas" will be deleted;
   %put NOTE- ;
   ,"GTL_SCATTER                                                     "
   %put NOTE- Element of type macro generated from the file "heatmap.sas" will be deleted;
   %put NOTE- ;
   ,"HEATMAP                                                         "
   %put NOTE- Element of type macro generated from the file "scatter_matrix.sas" will be deleted;
   %put NOTE- ;
   ,"SCATTER_MATRIX                                                  "
  )
  and objtype = "MACRO"
  and libname  = "WORK"
  )
  or
  (
   objname in ("*"
  )
  and objtype in ("FORMAT" "FORMATC" "INFMT" "INFMTC")
  and libname  = "WORK"
  and memname = 'CORRFORMAT'
  )
  order by objtype, memname, objname
  ;
quit;
data _null_;
  do until(last.memname);
    set WORK._last_;
    by objtype memname;
    if first.memname then call execute("proc catalog cat = work." !! strip(memname) !! " force;");
    call execute("delete " !! strip(objname) !! " /  et =" !! objtype !! "; run;");
  end;
  call execute("quit;");
run;
proc delete data = WORK._last_;
run;
proc fcmp outlib = work.corrfcmp.package;
quit;

proc fcmp outlib = work.corrfcmp.packagemeta;
deletefunc corrMETA;
quit;

options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.corrfcmp), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%put; %put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));
proc SQL noprint;
quit;

data _null_; call symputx("_DS2_2_del_",0,"L"); run;
proc SQL noprint;
quit;

run;

data _null_ ;                                                                                         
  length SYSloadedPackages $ 32767;                                                                   
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                     
    do;                                                                                               
      do until(EOF);                                                                                  
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;              
        substr(SYSloadedPackages, 1+offset, 200) = value;                                             
      end;                                                                                            
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");              
      if INDEX(lowcase(SYSloadedPackages),'#corr(0.0.3)#')>0 then 
         do;                                                                                          
          SYSloadedPackages = tranwrd(SYSloadedPackages, '#corr(0.0.3)#', '##');  
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                         
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                  
          put "NOTE: " SYSloadedPackages = ;                                                          
         end ;                                                                                        
    end;                                                                                              
  stop;                                                                                               
run;                                                                                                  
%put NOTE: Unloading package corr, version 0.0.3, license MIT;
%put NOTE- *** END ***;
%put NOTE- ;
/* unload.sas end */
