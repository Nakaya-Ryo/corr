filename P6911276 list;

 %put NOTE- ;
 %put NOTE: Loading package corr, version 0.0.3, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-10-22T22:01:01; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Run %nrstr(%%)helpPackage(corr) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_; 
 if NOT ("*"=symget("cherryPick")) then do; 
  put "NOTE- "; 
  put "NOTE: *** Cherry Picking ***"; 
  put "NOTE- Cherry Picking in action!! Be advised that"; 
  put "NOTE- dependencies/required packages will not be loaded!"; 
  put "NOTE- "; 
 end; 
run; 
%include  P6911276(packagemetadata.sas) / nosource2; 

 data _null_;                                    
  call symputX("packageRequiredErrors", 0, "L"); 
 run;                                            
 %put NOTE- *Testing required SAS components*%sysfunc(DoSubL(%str(
 options nonotes nosource ;                          
 options ls=max ps=max locale=en_US ;                
 /* temporary redirect log */                        
 filename _stinit_ TEMP ;                            
 proc printto log = _stinit_ ; run ;                 
 /* print out setinit */                             
 proc setinit ; run ;                                
 proc printto ; run ;                                
 options ps=min ;                                    
 data _null_ ;                                       
   /* loadup checklist of required SAS components */ 
   if _n_ = 1 then                                   
     do ;                                            
       length req $ 256 ;                            
       declare hash R() ;                            
       _N_ = R.defineKey("req") ;                    
       _N_ = R.defineDone() ;                        
       declare hiter iR("R") ;                       
         do req = %bquote(
"BASE SAS SOFTWARE"
) ; 
          _N_ = R.add(key:req,data:req) ;            
         end ;                                       
     end ;                                           
                                                     
   /* read in output from proc setinit */            
   infile _stinit_ end=eof ;                         
   input ;                                           
                                                     
   /* if component is in setinit remove it from checklist */ 
   if _infile_ =: "---" then                         
     do ;                                            
       req = upcase(substr(_infile_, 4, 64)) ;       
       if R.find(key:req) = 0 then                   
         do ;                                        
           _N_ = R.remove() ;                        
         end ;                                       
     end ;                                           
                                                     
   /* if checklist is not null rise error */         
   if eof and R.num_items > 0 then                   
     do ;                                            
       put "WARNING- ###########################################" ; 
       put "WARNING:  The following SAS components are missing! " ; 
       call symputX("packageRequiredErrors", 0, "L") ;              
       do while(iR.next() = 0) ;                                    
         put "WARNING-   " req ;                                    
       end ;                                                        
       put "WARNING:  The package may NOT WORK as expected      " ; 
       put "WARNING:  or even result with ERRORS!               " ; 
       put "WARNING- ###########################################" ; 
       put ;                                         
     end ;                                           
 run ;                                               
 filename _stinit_ clear ;                           
 options notes source ;                              
 )))*;                                               
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_;                                                     
  if 1 = symgetn("packageRequiredErrors") then                    
    do;                                                           
      put "ERROR: Loading package &packageName. will be aborted!";
      put "ERROR- Required components are missing.";              
      put "ERROR- *** STOP ***";                                  
      call symputX("packageRequiredErrors",
     'options ls = &ls_tmp. ps = &ps_tmp. 
       &notes_tmp. &source_tmp. msglevel=&msglevel_tmp. 
       &stimer_tmp. &fullstimer_tmp. ;
       data _null_;abort;run;', "L");              
    end;                                            
  else                                              
    call symputX("packageRequiredErrors", " ", "L");
 run;                                               
 &packageRequiredErrors.                            
 options &temp_noNotes_etc.;                        
 
%if (%str(*)=%superq(cherryPick)) or (association_matrix in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "association_matrix.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(association_matrix)=1, NOTE# Macro association_matrix exist. It will be overwritten by the macro from the corr package, ));
  %include P6911276(_06_macro.association_matrix.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (gtl_bar in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "gtl_bar.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(gtl_bar)=1, NOTE# Macro gtl_bar exist. It will be overwritten by the macro from the corr package, ));
  %include P6911276(_06_macro.gtl_bar.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (gtl_box in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "gtl_box.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(gtl_box)=1, NOTE# Macro gtl_box exist. It will be overwritten by the macro from the corr package, ));
  %include P6911276(_06_macro.gtl_box.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (gtl_crosstable in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "gtl_crosstable.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(gtl_crosstable)=1, NOTE# Macro gtl_crosstable exist. It will be overwritten by the macro from the corr package, ));
  %include P6911276(_06_macro.gtl_crosstable.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (gtl_ellipse in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "gtl_ellipse.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(gtl_ellipse)=1, NOTE# Macro gtl_ellipse exist. It will be overwritten by the macro from the corr package, ));
  %include P6911276(_06_macro.gtl_ellipse.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (gtl_kernel in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "gtl_kernel.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(gtl_kernel)=1, NOTE# Macro gtl_kernel exist. It will be overwritten by the macro from the corr package, ));
  %include P6911276(_06_macro.gtl_kernel.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (gtl_mosaic in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "gtl_mosaic.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(gtl_mosaic)=1, NOTE# Macro gtl_mosaic exist. It will be overwritten by the macro from the corr package, ));
  %include P6911276(_06_macro.gtl_mosaic.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (gtl_reg in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "gtl_reg.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(gtl_reg)=1, NOTE# Macro gtl_reg exist. It will be overwritten by the macro from the corr package, ));
  %include P6911276(_06_macro.gtl_reg.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (gtl_scatter in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "gtl_scatter.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(gtl_scatter)=1, NOTE# Macro gtl_scatter exist. It will be overwritten by the macro from the corr package, ));
  %include P6911276(_06_macro.gtl_scatter.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (heatmap in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "heatmap.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(heatmap)=1, NOTE# Macro heatmap exist. It will be overwritten by the macro from the corr package, ));
  %include P6911276(_06_macro.heatmap.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (scatter_matrix in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "scatter_matrix.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(scatter_matrix)=1, NOTE# Macro scatter_matrix exist. It will be overwritten by the macro from the corr package, ));
  %include P6911276(_06_macro.scatter_matrix.sas) / nosource2;
%end; 

data _null_;                                   
  call symputX("cherryPick_CASLUDF",  0, "L"); 
run;                                           
data _null_;                                   
length CASLUDF $ 32767;                        
dtCASLudf = datetime();                        
CASLUDF =                                      
    '%macro corrCASLudf('         
 !! "list=1,depList="                          
 !! ')/ des = ''CASL User Defined Functions loader for corr package'';'
 !! '  %if HELP = %superq(list) %then                               '
 !! '    %do;                                                       '
 !! '      %put ****************************************************************************;'
 !! '      %put This is help for the `corrCASLudf` macro;'
 !! '      %put Parameters (optional) are the following:;'
 !! '      %put - `list` indicates if the list of loaded CASL UDFs should be displayed,;'
 !! '      %put %str(  )when set to the value of `1` (the default) runs `FUNCTIONLIST USER%str(;)`,;'
 !! '      %put %str(  )when set to the value of `HELP` (upcase letters!) displays this help message.;'
 !! '      %put - `depList` [technical] contains the list of dependencies required by the package.;'
 !! '      %put %str(  )for _this_ instance of the macro the default value is: `.;'
 !! '      %put The macro generated: ' !! put(dtCASLudf, E8601DT19.-L) !! ";"
 !! '      %put with the SAS Packages Framework version 20260727.;'
 !! '      %put ****************************************************************************;'
 !! '    %GOTO theEndOfTheMacro;'
 !! '    %end;'
 !! '  %if %superq(depList) ne %then                                '
 !! '    %do;                                                       '
 !! '      %do i = 1 %to %sysfunc(countw(&depList.,%str( )));       '
 !! '        %let depListNm = %scan(&depList.,&i.,%str( ));         '
 !! '        %if %SYSMACEXIST(&depListNm.CASLudf) %then             '
 !! '          %do;                                                 '
 !! '            %&depListNm.CASLudf(list=0)                        '
 !! '          %end;                                                '
 !! '      %end;                                                    '
 !! '    %end;                                                      '
 !! '  %local tmp_NOTES;'                           
 !! '  %let tmp_NOTES = %sysfunc(getoption(NOTES));'
 !! "  filename P6911276 &ZIP. '&path./corr.&zip.';"
 !! "  options nonotes;"                      
 !! '  filename P6911276 clear;'    
 !! '  options &tmp_NOTES.;'                
 !! '   %if 1 = %superq(list) %then '       
 !! '     %do; '                            
 !! "       FUNCTIONLIST USER;"               
 !! "       run;"                             
 !! '     %end; '                           
 !! '%theEndOfTheMacro: %mend;';            
run;

data _null_;
run;
data _null_;
run;
%if (%str(*)=%superq(cherryPick)) %then %do;
proc fcmp outlib = work.corrfcmp.packagemeta ; 
 function corrMETA(meta $) $ 32767;
  m = char(upcase(meta),1);
   if m = 'V' then return(strip("0.0.3"));
   if m = 'D' then return(strip("2026-10-22T22:01:01"));
   if m = 'A' then return(strip("Ryo Nakaya (nakaya.ryou@gmail.com)"));
   if m = 'M' then return(strip("Ryo Nakaya (nakaya.ryou@gmail.com)"));
   if m = 'T' then return(strip("Correlation and Association Analysis"));
   if m = 'E' then return(strip("UTF8"));
   if m = 'L' then return(strip("2026-10-22T22:01:01"));
   if m = 'S' then return(strip("""BASE SAS SOFTWARE"""));
  return(" ");
 endfunc;
quit;
%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.corrfcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.corrfcmp);)
))
%macro corrMETA(meta)/parmbuff;
%if %superq(meta) = %then %return;
%do;%qsysfunc(strip(%qsysfunc(corrMETA&syspbuff.)))%end;
%mend;


%end;
%put NOTE- ;
%put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));

%if (%str(*)=%superq(cherryPick)) %then %do; 
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_ ;                                                                                              
  length SYSloadedPackages stringPCKG $ 32767;                                                              
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                           
    do;                                                                                                     
      do until(EOF);                                                                                        
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;                    
        substr(SYSloadedPackages, 1+offset, 200) = value;                                                   
      end;                                                                                                  
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");                    
      indexPCKG = INDEX(lowcase(SYSloadedPackages), '#corr(');                  
      if indexPCKG = 0 then                                                                                 
         do;                                                                                                
          SYSloadedPackages = catx('#', SYSloadedPackages, 'corr(0.0.3)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
      else                                                                                                  
         do;                                                                                                
          stringPCKG = kscanx(substr(SYSloadedPackages, indexPCKG+1), 1, '#');                              
          SYSloadedPackages = compbl(tranwrd(SYSloadedPackages, strip(stringPCKG), "#"));                   
          SYSloadedPackages = catx('#', SYSloadedPackages, 'corr(0.0.3)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
    end;                                                                                                    
  else                                                                                                      
    do;                                                                                                     
      call symputX('SYSloadedPackages', 'corr(0.0.3)', 'G');                            
      put / 'INFO: [SYSLOADEDPACKAGES] corr(0.0.3)';                                     
    end;                                                                                                    
  stop;                                                                                                     
 run;                                                                                                       
 options &temp_noNotes_etc.;
%end; 

options NOTES;
%put NOTE- ;
%put NOTE: Loading package corr, version 0.0.3, license MIT;
%put NOTE- *** END ***;

options &temp_noNotes_etc.;
%symdel temp_noNotes_etc / noWarn;
/* load.sas end */

